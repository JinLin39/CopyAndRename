﻿using System;
using System.IO;
using System.Linq;

try
{
    main();
}
catch (Exception ex)
{
    Console.WriteLine($"執行錯誤：{ex.Message}");
}

static void main()
{
    string[] sourcePaths = { @"d:\temp\FATA\temp01" };                              // 來源目錄
    string[] destinationPaths = { @"d:\temp\FATA\Back99", @"d:\temp\FATA\Back98" }; // 目的地目錄
    string[] searchPatterns = { "OD*.csv", "Sample*.csv" };                         // 檔案名稱模式

    foreach (var sourcePath in sourcePaths)
    {
        foreach (var pattern in searchPatterns)
        {
            if (!HasFiles(sourcePath, pattern))
                continue;

            foreach (var destinationPath in destinationPaths)
            {
                string[] sourceFilePaths = Directory.GetFiles(sourcePath, pattern);
                if (sourceFilePaths.Length == 0)
                {
                    Console.WriteLine($"找不到符合 {pattern} 的檔案於 {sourcePath}");
                    continue;
                }
                CopyFilesWithPattern(sourcePath, pattern, destinationPath);
                VerifyCopiedFiles(sourceFilePaths, destinationPath);
            }
        }
    }

    string[] matchedFilePaths = GetMatchedFiles(@"d:\temp\FATA\Back99", searchPatterns);
    /*
    string[] newFileNames = matchedFilePaths
        .Select((filePath, idx) => $"Report_{idx + 1}_{GetTodayString()}{Path.GetExtension(filePath)}")
        .ToArray();
     string[] newFileNames = { "ReportA.csv", "ReportB.csv", "ReportC.csv" };
     */
    // 假設 matchedFiles 已經取得
    string[] newFileNames = matchedFilePaths
        .Select(f => $"自訂名稱_{Path.GetFileNameWithoutExtension(f)}{Path.GetExtension(f)}")
        .ToArray();

    RenameFilesByList(matchedFilePaths, newFileNames);

    foreach (var destinationPath in destinationPaths)
    {
        if (!HasAllFiles(destinationPath, newFileNames))
        {
            Console.WriteLine($"目的地 {destinationPath} 沒有全部新檔名的檔案");
        }
        else
        {
            Console.WriteLine($"目的地 {destinationPath} 有全部新檔名的檔案");
        }
    }
}

static string[] GetMatchedFiles(string directory, string[] patterns)
{
    if (!Directory.Exists(directory))
    {
        Console.WriteLine($"來源目錄不存在：{directory}");
        return Array.Empty<string>();
    }

    var files = patterns
        .SelectMany(pattern => Directory.GetFiles(directory, pattern))
        .Distinct()
        .ToArray();

    return files;
}

static void CopyFilesWithPattern(string sourcePath, string pattern, string destinationPath)
{
    string[] sourceFilePaths = Directory.GetFiles(sourcePath, pattern);
    if (!Directory.Exists(destinationPath))
    {
        Directory.CreateDirectory(destinationPath);
    }
    for (int i = 0; i < sourceFilePaths.Length; i++)
    {
        string sourceFileName = Path.GetFileNameWithoutExtension(sourceFilePaths[i]);
        string destinationFileName = $"{sourceFileName}_{GetTodayString()}.csv";
        string destinationFilePath = Path.Combine(destinationPath, destinationFileName);

        try
        {
            File.Copy(sourceFilePaths[i], destinationFilePath, overwrite: true);
            Console.WriteLine($"檔案已成功複製到：{destinationFilePath}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"複製失敗：{ex.Message}");
        }
    }
}

static bool HasFiles(string path, string pattern)
{
    if (!Directory.Exists(path))
    {
        Console.WriteLine($"來源目錄不存在：{path}");
        return false;
    }
    string[] files = Directory.GetFiles(path, pattern);
    if (files.Length == 0)
    {
        Console.WriteLine($"找不到符合 {pattern} 的檔案於 {path}");
        return false;
    }
    return true;
}

static bool HasAllFiles(string directory, string[] fileNames)
{
    foreach (var fileName in fileNames)
    {
        string filePath = Path.Combine(directory, fileName);
        if (!File.Exists(filePath))
        {
            return false;
        }
    }
    return true;
}

static void VerifyCopiedFiles(string[] sourceFilePaths, string destinationPath)
{
    foreach (var sourceFilePath in sourceFilePaths)
    {
        string fileName = Path.GetFileNameWithoutExtension(sourceFilePath);
        string destinationFileName = $"{fileName}_{GetTodayString()}.csv";
        string destinationFilePath = Path.Combine(destinationPath, destinationFileName);

        if (!File.Exists(destinationFilePath))
        {
            Console.WriteLine($"檔案不存在於目的地：{destinationFilePath}");
        }
        else
        {
            long sourceLen = new FileInfo(sourceFilePath).Length;
            long destLen = new FileInfo(destinationFilePath).Length;
            if (sourceLen != destLen)
            {
                Console.WriteLine($"檔案大小不一致：{destinationFilePath}");
            }
            else
            {
                Console.WriteLine($"檔案驗證成功：{destinationFilePath}");
            }
        }
    }
}

static void RenameFile(string filePath, string newFileName)
{
    if (!File.Exists(filePath))
    {
        Console.WriteLine($"檔案不存在：{filePath}");
        return;
    }

    string directory = Path.GetDirectoryName(filePath)!;
    string newFilePath = Path.Combine(directory, newFileName);

    try
    {
        File.Move(filePath, newFilePath, overwrite: true);
        Console.WriteLine($"檔案已重新命名：{newFilePath}");
    }
    catch (Exception ex)
    {
        Console.WriteLine($"重新命名失敗：{ex.Message}");
    }
}

static void RenameFilesByList(string[] oldFilePaths, string[] newFileNames)
{
    if (oldFilePaths.Length != newFileNames.Length)
    {
        Console.WriteLine("檔案數量與新檔名數量不一致，無法執行批次重新命名。");
        return;
    }

    for (int i = 0; i < oldFilePaths.Length; i++)
    {
        RenameFile(oldFilePaths[i], newFileNames[i]);
    }
}

static string GetTodayString()
{
    return DateTime.Now.ToString("yyyyMMdd");
}
